"""LLM Code Harness modules."""
